//----------------MOVIE-ACTIONS-WMM---------------------

export const addToCollection = (movies) =>{
    return {
        type: "ADD_TO_COLLECTION",
        payload: movies
    }
}
export const deleteMovie = (movie) =>{
    return {
        type: "DELETE_MOVIE",
        payload: movie
    }
}
export const clearMovies = () => {
    return {
        type: "CLEAR_MOVIES"
    }
}
//----------------TV-ACTIONS-WMM---------------------

export const addToTvCollection = (show) =>{
    return {
        type: "ADD_TO_TV_COLLECTION",
        payload: show
    }
}
export const deleteShows = (shows) =>{
    return {
        type: "DELETE_SHOWS",
        payload: shows
    }
}
export const clearShows = () => {
    return {
        type: "CLEAR_SHOWS"
    }
}

//----------------FORM-SELECT-ACTIONS-WMM---------------------

export const selectForm = (formType) =>{
    return{
        type: "SELECT-FORM",
        payload: formType
    }
}
