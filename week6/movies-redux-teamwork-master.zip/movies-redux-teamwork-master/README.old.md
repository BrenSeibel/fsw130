# Movies-Redux-Teamwork
This is a repository created to work as a team to create a application with React and Redux
