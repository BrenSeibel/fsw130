import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { addToCollection, 
        clearMovies,addToTvCollection, clearShows, selectForm, deleteShows, deleteMovie } from '../actions/'
import Form from './Form'
import ListItems from './ListItems'

const FormType = () => {

    const formType = useSelector(form => form)
    const dispatch = useDispatch()

    return(
        <div className = "main">
            <div className="button-div">
                <button onClick = { ()=> dispatch(selectForm("movies"))}>Movie Form</button>
                <button onClick = { ()=> dispatch(selectForm("tvShows"))}>TV Form</button>
            </div>

            { formType.formTypeReducer=== "movies"?
                <>
                    <Form
                        collection = {addToCollection}
                        clearCollection = {clearMovies}
                        btnName = "Movies"           
                     />

                    <ListItems
                        collection = {formType.movieReducer}
                        deleteItem = {deleteMovie}
                        type = "Movies"
                    />
                </>
            :
                <>
                    <Form
                        collection = {addToTvCollection}
                        clearCollection = {clearShows}
                        btnName = "TV Shows"           
                     />

                    <ListItems
                        collection = {formType.tvReducer}
                        deleteItem = {deleteShows}
                        type = "Tv Shows"
                    />
                </>

            }
            
        </div>
    )
}

export default FormType