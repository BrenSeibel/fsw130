import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'


const Form = ({ collection, btnName, clearCollection}) =>{

    

    const dispatch = useDispatch();
    const movie = useSelector(state=> state)

    const intiInputs = {
        title: "",
        description: ""
    }
     const [inputs, setInputs] = useState(intiInputs)
    
    const handleChange = (e) => {
        const {name, value} = e.target
        setInputs(prevInputs => ({...prevInputs, [name]: value}))
    }

    const submit = (event) =>{
        event.preventDefault()
        dispatch(collection(inputs))
        setInputs(intiInputs)
    }    

    return (
        <div className="main">            
             <form name = "form"onSubmit={(e)=>{submit(e)}} className="mainForm">          
                <input 
                    type ="text" 
                    name="title"
                    value = {inputs.title}
                    placeholder = {`${btnName} Title...`}
                    onChange = {handleChange} 
                    required/>
                
                <input  
                    type="text"
                    name = "description" 
                    value = {inputs.description}
                    placeholder= {`${btnName} Description...`}
                    onChange = {handleChange} 
                    required/>
                
                <div >
                    <button >Add {btnName}</button>
                    <button onClick={()=>dispatch(clearCollection())}>Clear {btnName}</button>
                </div>                
            </form>  
            
                 
        </div>
      );
    };

export default Form;
