import React from 'react';
import FormType from './components/FormType'
import './App.css';

function App() {
  return (
    <div className="App">
      <FormType/>
    </div>
  );
}

export default App;
