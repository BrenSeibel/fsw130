//COMBINED-REDUCER--WMM-

import movieReducer from './movieReducer'
import tvReducer from './tvReducer'
import { combineReducers } from 'redux'


const combine = combineReducers({
    movieReducer,
    tvReducer
})

export default combine